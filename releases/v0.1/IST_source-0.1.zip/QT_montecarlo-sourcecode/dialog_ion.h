#ifndef DIALOG_ION_H
#define DIALOG_ION_H

#include <QDialog>
#include <mainwindow.h>

namespace Ui {
class Dialog_ion;
}

class Dialog_ion : public QDialog
{
    Q_OBJECT
    
public:
    explicit Dialog_ion(QWidget *parent = 0);
    ~Dialog_ion();

    int lat_front; //0 lateral, 1 frontal
    QString ion_path, vac_path;
    double straggl, ntherm, ptherm, nsigma, psigma, fluence, radhard;

    
private slots:

public slots:
    void on_radioButton_lateral_clicked();

    void on_radioButton_frontal_clicked();

    void on_buttonBox_accepted();

    void on_pushButton_ionfile_clicked();

    void on_pushButton_vacfile_clicked();

private:
    Ui::Dialog_ion *ui;
};

#endif // DIALOG_ION_H
